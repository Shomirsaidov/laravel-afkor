

<?php $__env->startSection('page-title'); ?> Recent Events <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="space-y-8">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="shadow-lg border-2 p-4 rounded-md">
                <div class="flex items-center space-x-2">
                    <div style="width: 40px; height: 40px; background: #cecece"></div>
                    <h3 class="text-blue-800 text-lg"><?php echo e($post->author); ?></h3>        
                </div>
                <h2 class="text-center font-bold"><?php echo e($post->title); ?></h2>
                <p class="text-md mt-2"><?php echo e($post->text); ?></p>        
                <p class="text-blue-600 mt-8 text-end"><?php echo e($post->date); ?></p>        
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\laravel\afkor\resources\views/posts.blade.php ENDPATH**/ ?>