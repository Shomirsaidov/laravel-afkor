

<?php $__env->startSection('page-title'); ?> About page <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <h1>About us page Mr.<?php echo e($name[0]->title); ?></h1>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\laravel\afkor\resources\views/about.blade.php ENDPATH**/ ?>