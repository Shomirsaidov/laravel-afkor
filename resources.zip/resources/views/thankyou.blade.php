@extends('layout.app')

@section('page-title') Спасибо за покупку ! @endsection

@section('content')

    <div class=" p-4 border-4 rounded-xl mt-16 shadow-lg">
        <h1 class="text-green-600 text-xl font-bold">Спасибо за покупку ! <br> Скоро с вами свяжется наш представитель для обсуждения деталей покупки.</h1>
    </div>

@endsection