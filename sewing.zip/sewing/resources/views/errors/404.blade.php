@extends('layout.app')

@section('page-title') Ooops @endsection

@section('content')


    <h1 class="text-red-800 text-2xl bg-yellow-300 font-black text-center">Fuck of here !</h1>

@endsection