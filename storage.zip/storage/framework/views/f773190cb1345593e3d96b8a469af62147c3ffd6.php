

<?php $__env->startSection('page-title'); ?>
    Jobify Welcome Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center items-center">
            <form class="shadow-lg space-y-2 p-8 grid" action="<?php echo e(route('post')); ?>" method="POST">
                <h1 class="my-4">Leave a feedback about this Jobify !</h1>
                <?php echo csrf_field(); ?>
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <h3 class="text-red-500"><?php echo e($message); ?></h3>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input placeholder="Title" type="text" class="border-2 p-2 text-md outline-none rounded-md" name="title" value="<?php echo e(old('title')); ?>">
                <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <h3 class="text-red-500"><?php echo e($message); ?></h3>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <textarea placeholder="Feedback text" type="text" class="border-2 p-2 text-md outline-none rounded-md" name="text" value="<?php echo e(old('text')); ?>"></textarea>
                
                <input placeholder="Choose a nick" type="text" class="border-2 p-2 text-md outline-none rounded-md" name="author" value="<?php echo e(old('author')); ?>">
                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <h3 class="text-red-500"><?php echo e($message); ?></h3>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="date" class="border-2 p-2 text-md outline-none rounded-md" name="date" value="<?php echo e(old('date')); ?>"><br>
               
            
                <button type="submit" class="bg-green-600 w-full p-2 rounded-md text-white">Submit</button>
            </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\laravel\afkor\resources\views/register.blade.php ENDPATH**/ ?>