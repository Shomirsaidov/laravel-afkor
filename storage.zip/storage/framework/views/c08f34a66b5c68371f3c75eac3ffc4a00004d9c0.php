

<?php $__env->startSection('page-title'); ?> Последние заказы <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div>
        <h1 class="text-2xl font-bold mt-4">Последние заказы</h1>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="shadow-md border-2 p-4 my-4 space-y-2">
                <h1><?php echo e($order->name); ?></h1>
                <h1><?php echo e($order->address); ?></h1>
                <h1><?php echo e($order->tel); ?></h1>
                <h1><?php echo e($order->product_name); ?></h1>
                <h1><?php echo e($order->price); ?></h1>
                <h1><?php echo e($order->created_at); ?></h1>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\sewing\resources\views/orders.blade.php ENDPATH**/ ?>