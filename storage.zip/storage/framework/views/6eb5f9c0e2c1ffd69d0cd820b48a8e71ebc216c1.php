<?php $__env->startSection('nav'); ?>
<div class=" bg-indigo-400 p-4 lg:px-64 text-white font-bold fixed  fixed-top top-0 w-full">
        <nav class="flex w-full justify-between items-center">
            <img src="/assets/logo.png" width="40" alt="">
            <a href="/">Купить</a>
            <a href="/orders">Заказы</a>
            <a href="/profile">Профиль</a>
            <a href="/basket">Корзина</a>
        </nav>
</div><?php /**PATH C:\Users\User\Desktop\sewing\resources\views/inc/nav.blade.php ENDPATH**/ ?>