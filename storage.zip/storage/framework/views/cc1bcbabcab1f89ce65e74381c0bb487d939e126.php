

<?php $__env->startSection('page-title'); ?>
    <?php echo e(Request::route('category') . ' \ ' . Request::route('section')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div>
        <h1 class="text-xl font-bold my-8"><?php echo e(Request::route('category') . ' \ ' . Request::route('section')); ?></h1>
        <div class="space-x-2 overflow-x-auto snap-x snap-mandatory">
            <?php if(count($data) > 0): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="min-width: 200px;" class="flex flex-col justify-center items-center text-center border-4 rounded-xl p-4 cursor-pointer snap-center">
                        <div class="flex flex-col items-center">
                            <img src="<?php echo e(json_decode($product->images)[0]); ?>" alt="" width="200">
                            <h1 class="font-bold my-4"><?php echo e($product->name); ?></h1>
                            <h1 class="font-bold text-green-700 my-2">$<?php echo e($product->price); ?></h1>
                        </div>
                        <div class="w-full h-full flex items-end">
                                <a href="/product/<?php echo e($product->id); ?>" class="bg-blue-800 text-white p-2 rounded-xl mt-2 w-full">
                                    Смотреть
                                </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?> 
                <h1>Nothing to see</h1>
            <?php endif; ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\sewing\resources\views/feed.blade.php ENDPATH**/ ?>