<div>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e('/categories/' . $category->category); ?>">
            <div class="p-4 shadow-xl border-2 font-black text-2xl mt-4 cursor-pointer hover:shadow rounded-lg">
                <p><?php echo e($category->section); ?></p>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div><?php /**PATH C:\Users\User\Desktop\sewing\resources\views/inc/sections.blade.php ENDPATH**/ ?>