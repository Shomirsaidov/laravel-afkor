

<?php $__env->startSection('page-title'); ?> Профиль <?php echo e(Auth::user()->name); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class=" p-4 border-4 rounded-xl mt-16 shadow-lg">

    <?php if(Auth::check()): ?>
        <p>Welcome, <?php echo e(Auth::user()->name); ?>!</p>
        <h1><?php echo e(Auth::user()->tel); ?></h1>
        <h1><?php echo e(Auth::user()->email); ?></h1>
        <h1><?php echo e(Auth::user()->role); ?></h1>
    <?php else: ?>
        <p>Please log in.</p>
    <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\sewing\resources\views/profile.blade.php ENDPATH**/ ?>