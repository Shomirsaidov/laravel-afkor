<?php $__env->startSection('nav'); ?>
<div class="flex justify-center bg-blue-300 p-4">
        <nav class="flex w-full justify-between">
            <a href="/">Home</a>
            <a href="/register">Register</a>
            <a href="/posts">Users Feedback</a>
            <a href=""></a>
        </nav>
</div><?php /**PATH C:\Users\User\Desktop\laravel\afkor\resources\views/inc/nav.blade.php ENDPATH**/ ?>