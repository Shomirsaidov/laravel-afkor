@extends('layout.app')

@section('page-title') SewingTJ @endsection

@section('content')

    @include('inc.categories')

@endsection