

<?php $__env->startSection('page-title'); ?> Ooops <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <h1 class="text-red-800 text-2xl bg-yellow-300 font-black text-center">Fuck of here !</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\sewing\resources\views/errors/404.blade.php ENDPATH**/ ?>