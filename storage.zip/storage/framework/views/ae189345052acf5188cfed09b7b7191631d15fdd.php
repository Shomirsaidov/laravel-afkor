<div>
    <h1 class="text-xl font-bold my-4">Похожие товары</h1>
    <div class="flex space-x-2 overflow-x-auto snap-x snap-mandatory">
        <?php if($similars): ?>
            <?php $__currentLoopData = $similars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="min-width: 200px;" class="flex flex-col justify-center items-center text-center border-4 rounded-xl p-4 cursor-pointer my-4 snap-center">
                    <div class="flex flex-col items-center">
                        <img src="<?php echo e(json_decode($product->images)[0]); ?>" alt="" width="200">
                        <h1 class="font-bold my-4"><?php echo e($product->name); ?></h1>
                        <h1 class="font-bold text-green-700 my-2">$<?php echo e($product->price); ?></h1>
                    </div>
                    <div class="w-full h-full flex items-end">
                            <a href="/product/<?php echo e($product->id); ?>" class="bg-blue-800 text-white p-2 rounded-xl mt-2 w-full">
                                Смотреть
                            </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\User\Desktop\sewing\resources\views/inc/similar.blade.php ENDPATH**/ ?>