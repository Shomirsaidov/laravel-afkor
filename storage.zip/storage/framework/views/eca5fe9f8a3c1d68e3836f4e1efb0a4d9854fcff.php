

<?php $__env->startSection('page-title'); ?> Спасибо за покупку ! <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class=" p-4 border-4 rounded-xl mt-16 shadow-lg">
        <h1 class="text-green-600 text-xl font-bold">Спасибо за покупку ! <br> Скоро с вами свяжется наш представитель для обсуждения деталей покупки.</h1>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\sewing\resources\views/thankyou.blade.php ENDPATH**/ ?>